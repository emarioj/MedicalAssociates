﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace Medical_Associate
{
    public partial class Coming_Soon : MetroForm
    {
        public Coming_Soon()
        {
            InitializeComponent();
        }

        private void Coming_Soon_Load(object sender, EventArgs e)
        {

        }
    }
}
