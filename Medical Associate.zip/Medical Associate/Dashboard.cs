﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace Medical_Associate
{
    public partial class Dashboard : MetroForm
    {
        DoctorsStatu dst = new DoctorsStatu();
        public Dashboard()
        {
            InitializeComponent();
        }

        //Use timer class

        Timer tmr;
        //Timer tmr2;

        private void Dasboard_Load(object sender, EventArgs e)
        {

            tmr = new Timer();
            //tmr2 = new Timer();

            //set time interval 10 sec

            tmr.Interval = 1000;
           // tmr2.Interval = 30000;

            //starts the timer
            //tmr2.Start();
            tmr.Start();

            //tmr2.Tick += tmr_Tick2;
            tmr.Tick += tmr_Tick;
        }
        void tmr_Tick2(object sender, EventArgs e)

        {
            //if (radioButton4.Checked == true)
            //{
            //    dst.Dr_Busy = "";
            //}
            //else if (radioButton5.Checked == true)
            //{
            //    dst.Dr_IN = "";
            //}
            //else {
            //    dst.Dr_OUT = "";
            //}
        }
        void tmr_Tick(object sender, EventArgs e)

        {

            //update time label
            label3.Text = DateTime.Now.ToString();
            label4.Text = TimeZone.CurrentTimeZone.DaylightName.ToString();

            

        }

        private void Dashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Patients np = new Patients();
            np.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Invoice inx = new Invoice();
            inx.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Lab lb = new Lab();
            lb.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Coming_Soon cmg = new Coming_Soon();
            cmg.Show();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            Config_Forms conf = new Config_Forms();
            conf.Show();
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            Prescription pr = new Prescription();
            pr.Show();
        }

        //private void radioButton4_Click(object sender, EventArgs e)
        //{

        //    try
        //    {
        //        if (radioButton6.Checked == true)
        //        {
        //            dst.Dr_IN = "False";
        //            dst.Dr_Busy = "False";
        //            dst.Dr_OUT = "True";
        //        }
        //        else if (radioButton5.Checked == true)
        //        {
        //            dst.Dr_IN = "True";
        //            dst.Dr_Busy = "False";
        //            dst.Dr_OUT = "False";

        //        }
        //        else
        //        {
        //            dst.Dr_IN = "True";
        //            dst.Dr_Busy = "False";
        //            dst.Dr_OUT = "False";
        //        }
        //        using (medicalAssociatesEntities db = new medicalAssociatesEntities())
        //        {
        //            dst = db.DoctorsStatus.Where(x => x.Id == 1).FirstOrDefault();
        //            db.Entry(dst).State = EntityState.Modified;
        //            db.SaveChanges();
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //        //tmr2.Stop();
        //        MessageBox.Show("Sorry an error occured trying to update Doctors Status"+ex+"");

        //        //throw;
        //    }

        //}

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

            dst.Dr_IN = "True";
            dst.Dr_Busy = "False";
            dst.Dr_OUT = "False";


            using (medicalAssociatesEntities db = new medicalAssociatesEntities())
            {
                dst = db.DoctorsStatus.Where(x => x.Id == 1).FirstOrDefault();
                db.Entry(dst).State = EntityState.Modified;
                db.SaveChanges();
            }
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            dst.Dr_IN = "False";
            dst.Dr_Busy = "False";
            dst.Dr_OUT = "True";


            using (medicalAssociatesEntities db = new medicalAssociatesEntities())
            {
                dst = db.DoctorsStatus.Where(x => x.Id == 1).FirstOrDefault();
                db.Entry(dst).State = EntityState.Modified;
                db.SaveChanges();
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

            dst.Dr_IN = "False";
            dst.Dr_Busy = "True";
            dst.Dr_OUT = "False";


            using (medicalAssociatesEntities db = new medicalAssociatesEntities())
            {
                dst = db.DoctorsStatus.Where(x => x.Id == 1).FirstOrDefault();
                db.Entry(dst).State = EntityState.Modified;
                db.SaveChanges();
            }
        }
    }
}
 
