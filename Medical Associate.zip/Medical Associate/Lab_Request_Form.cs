﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace Medical_Associate
{
    public partial class Lab_Request_Form : MetroForm
    {
        public Lab_Request_Form()
        {
            InitializeComponent();
        }

        private void Lab_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet.Lab_Tests' table. You can move, or remove it, as needed.
            this.lab_TestsTableAdapter.Fill(this.medicalAssociatesDataSet.Lab_Tests);

        }

        private void button14_Click(object sender, EventArgs e)
        {

        }
    }
}
