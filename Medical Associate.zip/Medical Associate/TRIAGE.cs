﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace Medical_Associate
{
    public partial class TRIAGE : MetroForm
    {
        TRAIGE trge = new TRAIGE();
        public TRIAGE()
        {
            InitializeComponent();
        }

        private void TRIAGE_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet3.Patient_Cue' table. You can move, or remove it, as needed.
            this.patient_CueTableAdapter.Fill(this.medicalAssociatesDataSet3.Patient_Cue);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            trge.Blood_pressure = metroTextBox8.Text.ToString();
            trge.Bod_temp = metroTextBox1.Text.ToString();
            trge.Height = Convert.ToInt32(metroTextBox13.Text);
            trge.Weight = Convert.ToInt32(metroTextBox9.Text);
            trge.MUAC = metroTextBox11.Text.ToString();
            trge.Note = metroTextBox12.Text.ToString();
            trge.Respiratory_rate = metroTextBox10.Text.ToString();

            using (medicalAssociatesTraigeEntities db = new medicalAssociatesTraigeEntities())
            {

                db.TRAIGEs.Add(trge);
                db.SaveChanges();

            }

            MessageBox.Show("Patient TRAIGE Has been added Succefully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void metroGrid1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (metroGrid1.CurrentRow.Index != -1)
            {
                
                metroLabel1.Text = Convert.ToInt32(metroGrid1.CurrentRow.Cells["PatientID"].Value).ToString(); ;
            }
        }
    }
}
