﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace Medical_Associate
{
    public partial class Lab : MetroForm
    {
        public Lab()
        {
            InitializeComponent();
        }

        private void Lab_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet3.Patient_Cue' table. You can move, or remove it, as needed.
            this.patient_CueTableAdapter.Fill(this.medicalAssociatesDataSet3.Patient_Cue);
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet.Lab_Tests' table. You can move, or remove it, as needed.
            this.lab_TestsTableAdapter.Fill(this.medicalAssociatesDataSet.Lab_Tests);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Lab_Request_Form lrf = new Lab_Request_Form();
            lrf.Show();
            lrf.Name = "test";
        }
    }
}
