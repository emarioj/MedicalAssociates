﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace Medical_Associate
{
    public partial class Patients : MetroForm
    {
        Patient_Cue pcue = new Patient_Cue();
        Patient_List plst = new Patient_List();
        TRAIGE trg = new TRAIGE();
        public Patients()
        {
            InitializeComponent();
        }

        private void Patients_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medicalAssociatesDataSetTraige.TRAIGE' table. You can move, or remove it, as needed.
            this.tRAIGETableAdapter.Fill(this.medicalAssociatesDataSetTraige.TRAIGE);
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet3.Patient_Cue' table. You can move, or remove it, as needed.
            this.patient_CueTableAdapter.Fill(this.medicalAssociatesDataSet3.Patient_Cue);
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet3.Patient_List' table. You can move, or remove it, as needed.
            this.patient_ListTableAdapter.Fill(this.medicalAssociatesDataSet3.Patient_List);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            New_Patient np = new New_Patient();
            if (np.Visible != true)
            {

                np.Show();

            }
            else
            {
                MessageBox.Show("Window Already active","Info",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (metroGrid1.CurrentRow.Index != -1)
            {
                metroLabel6.Text = Convert.ToInt32(metroGrid1.CurrentRow.Cells["PatientID"].Value).ToString();
                pcue.PatientID = Convert.ToInt32(metroGrid1.CurrentRow.Cells["PatientID"].Value);
                pcue.First_Name = metroGrid1.CurrentRow.Cells["firstName"].Value.ToString();
                pcue.Second_Name = metroGrid1.CurrentRow.Cells["secondName"].Value.ToString();
                pcue.Age = Convert.ToInt32(metroGrid1.CurrentRow.Cells["age"].Value);
                pcue.Date = Convert.ToDateTime(metroGrid1.CurrentRow.Cells["date"].Value);

                using (medicalAssociatesEntities db = new medicalAssociatesEntities())
                {
                    db.Patient_Cue.Add(pcue);
                    db.SaveChanges();
                }
                MessageBox.Show("Patient Has been added to the CUE Succefully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

                TRIAGE tr = new TRIAGE();
                tr.Show();
                
            }
        }

        private void Patients_Activated(object sender, EventArgs e)
        {

            // TODO: This line of code loads data into the 'medicalAssociatesDataSet3.Patient_List' table. You can move, or remove it, as needed.
            this.patient_ListTableAdapter.Fill(this.medicalAssociatesDataSet3.Patient_List);
        }

        private void metroGrid1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (metroGrid1.CurrentRow.Index != -1)
            {
                //metroLabel6.Text = Convert.ToInt32(metroGrid1.CurrentRow.Cells["Service_Number"].Value).ToString();
                pcue.PatientID = Convert.ToInt32(metroGrid1.CurrentRow.Cells["PatientID"].Value);
                metroLabel11.Text = metroGrid1.CurrentRow.Cells["firstNameData"].Value.ToString();
                metroLabel12.Text = metroGrid1.CurrentRow.Cells["secondNameData"].Value.ToString();
                metroLabel9.Text = Convert.ToInt32(metroGrid1.CurrentRow.Cells["ageData"].Value).ToString();
                pcue.Date = DateTime.Today;

                using (medicalAssociatesEntities db = new medicalAssociatesEntities())
                {
                    db.Patient_Cue.Add(pcue);
                    db.SaveChanges();
                }
                MessageBox.Show("Patient Has been added to the CUE Succefully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }
        }

        private void metroGrid2_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (metroGrid2.CurrentRow.Index != -1)
            {
                pcue.PatientID = Convert.ToInt32(metroGrid2.CurrentRow.Cells["Patient_ID"].Value);

                plst.Id = Convert.ToInt32(metroGrid2.CurrentRow.Cells["Patient_ID"].Value);
                trg.PatientID = Convert.ToInt32(metroGrid2.CurrentRow.Cells["Patient_ID"].Value);
                var pID = trg.PatientID = Convert.ToInt32(metroGrid2.CurrentRow.Cells["Patient_ID"].Value);

                using (medicalAssociatesEntities db = new medicalAssociatesEntities())
                {
                    pcue = db.Patient_Cue.Where(x => x.PatientID == pcue.PatientID).FirstOrDefault();
                    plst = db.Patient_List.Where(x => x.Id == plst.Id).FirstOrDefault();
                    
                    metroLabel6.Text = pcue.Service_Number.ToString();
                    metroLabel11.Text = pcue.First_Name.ToString();
                    metroLabel12.Text = pcue.Second_Name.ToString();
                    metroLabel9.Text = pcue.Age.ToString();
                    metroLabel23.Text = pcue.Date.ToString();

                    metroLabel7.Text = plst.Address.ToString();
                    metroLabel10.Text = "0"+plst.Contact.ToString();
                    metroTextBox2.Text = plst.Note.ToString();
                    metroLabel29.Text = plst.Status.ToString();
                    
                }
                //if (pID >= 0)
                //{

                //    using (medicalAssociatesTraigeEntities dbt = new medicalAssociatesTraigeEntities())
                //    {
                //        trg = dbt.TRAIGEs.Where(x => x.PatientID == pID).FirstOrDefault();

                //        metroLabel21.Text = trg.Blood_pressure.ToString();
                //        metroLabel20.Text = trg.Respiratory_rate.ToString();
                //        metroLabel22.Text = trg.MUAC.ToString();
                //        metroLabel24.Text = trg.Weight.ToString();
                //        metroLabel26.Text = trg.Height.ToString();
                //        metroLabel25.Text = trg.Bod_temp.ToString();
                //        metroTextBox3.Text = trg.Note.ToString();
                //    }
                //}
                //else {

                //    MessageBox.Show("Sorry Doctor The TRAIGE for this Patient Has Not yet been Registered","Info",MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //}

            }
        }

        private void metroGrid2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
