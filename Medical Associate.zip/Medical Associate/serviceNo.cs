﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Medical_Associate
{
    class serviceNo
    {
        void serviceNumber() {

            var serviveNum = "";
        }
    }
}
