﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace Medical_Associate
{
    public partial class Prescription : MetroForm
    {
        public Prescription()
        {
            InitializeComponent();
        }

        private void Prescription_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet.Lab_Tests' table. You can move, or remove it, as needed.
            this.lab_TestsTableAdapter.Fill(this.medicalAssociatesDataSet.Lab_Tests);
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet2.Consumables' table. You can move, or remove it, as needed.
            this.consumablesTableAdapter.Fill(this.medicalAssociatesDataSet2.Consumables);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("calc.exe");
            p.WaitForInputIdle();
        }

        private void button14_Click(object sender, EventArgs e)
        {

        }
    }
}
