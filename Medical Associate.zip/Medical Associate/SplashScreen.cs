﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace Medical_Associate
{
    public partial class SplashScreen : MetroForm
    {
        public SplashScreen()
        {
            InitializeComponent();
        }

        private void SplashScreen_Load(object sender, EventArgs e)
        {

        }
        //Use timer class

        Timer tmr;

        private void SplashScreen_Shown(object sender, EventArgs e)

        {

            tmr = new Timer();

            //set time interval 10 sec

            tmr.Interval = 10000;

            //starts the timer

            tmr.Start();

            tmr.Tick += tmr_Tick;

        }

        void tmr_Tick(object sender, EventArgs e)

        {

            //after 10 sec stop the timer

            tmr.Stop();

            //display mainform

            Login mf = new Login();



            mf.Show();

            //hide this form

            this.Hide();

        }
    }
}
