﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace Medical_Associate
{
    public partial class Config_Forms : MetroForm
    {
        Lab_Tests labModel = new Lab_Tests();
        X_Rays xry = new X_Rays();
        Consumable cons = new Consumable();
        public Config_Forms()
        {
            InitializeComponent();
        }

        private void Config_Forms_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet2.Consumables' table. You can move, or remove it, as needed.
            this.consumablesTableAdapter.Fill(this.medicalAssociatesDataSet2.Consumables);
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet1._X_Rays' table. You can move, or remove it, as needed.
            this.x_RaysTableAdapter.Fill(this.medicalAssociatesDataSet1._X_Rays);
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet.Lab_Tests' table. You can move, or remove it, as needed.
            this.lab_TestsTableAdapter.Fill(this.medicalAssociatesDataSet.Lab_Tests);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            labModel.Name = metroTextBox8.Text.ToString();
            labModel.Price = Convert.ToInt32(metroTextBox1.Text);

            using (medicalAssociatesEntities db = new medicalAssociatesEntities())
            {
                db.Lab_Tests.Add(labModel);
                db.SaveChanges();
            }
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet.Lab_Tests' table. You can move, or remove it, as needed.
            this.lab_TestsTableAdapter.Fill(this.medicalAssociatesDataSet.Lab_Tests);
            MessageBox.Show("Has been Registered Succefully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

            metroTextBox8.Text = metroTextBox1.Text = "";

        }

        private void button6_Click(object sender, EventArgs e)
        {
            xry.Name = metroTextBox3.Text.ToString();
            xry.Price = Convert.ToInt32(metroTextBox2.Text);

            using (medicalAssociatesEntities db = new medicalAssociatesEntities())
            {
                db.X_Rays.Add(xry);
                db.SaveChanges();
            }
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet1._X_Rays' table. You can move, or remove it, as needed.
            this.x_RaysTableAdapter.Fill(this.medicalAssociatesDataSet1._X_Rays);
            MessageBox.Show("Has been Registered Succefully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

            metroTextBox3.Text = metroTextBox2.Text = "";

        }

        private void button9_Click(object sender, EventArgs e)
        {
            cons.Name = metroTextBox5.Text;
            cons.Current_stock = Convert.ToInt32(metroTextBox6.Text);
            cons.Price = Convert.ToInt32(metroTextBox4.Text);

            using (medicalAssociatesEntities db = new medicalAssociatesEntities())
            {
                db.Consumables.Add(cons);
                db.SaveChanges();
            }
            // TODO: This line of code loads data into the 'medicalAssociatesDataSet2.Consumables' table. You can move, or remove it, as needed.
            this.consumablesTableAdapter.Fill(this.medicalAssociatesDataSet2.Consumables);
            MessageBox.Show("Has been Registered Succefully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

            metroTextBox5.Text = metroTextBox6.Text = metroTextBox4.Text = "";

        }
    }
}
